<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>SLC VMS</title>
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
            crossorigin="anonymous"
        />
        <link rel="stylesheet" href="./style.css" />
        <!-- Google Fonts -->
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&icon_names=download"
        />
    </head>
    <body>
        <!-- Hero Section -->
        <div class="hero d-flex justify-content-center align-items-center container-fluid">
            <div class="container">
                <h1 class="pt-5 pb-2 text-center">Supplier Registration</h1>
                <p class="mb-4">
                    At Sri Lanka Cricket, we are committed to fostering strong partnerships with suppliers who share our
                    dedication to quality, integrity, and innovation. By becoming a registered supplier, you'll join a
                    trusted network that plays a vital role in supporting the growth and success of cricket in Sri
                    Lanka. If you provide goods or services that meet our standards, we invite you to register with us
                    and be part of our journey toward excellence!
                </p>
                <div class="row pb-5">
                    <div class="col d-flex justify-content-center">
                        <button type="button" class="btn btn-info"><span>Register Now</span></button>
                    </div>
                </div>
            </div>
        </div>

        <section class="section-1">
            <div class="container">
                <div class="row pt-8 mb-4">
                    <h2 class="fw-semibold headings">More Details</h2>
                </div>

                <div class="row g-5">
                    <div class="col-6">
                        <div class="container p-5 box box-1">
                            <div class="col"><h3>How to Register</h3></div>
                            <div class="col">
                                <p>
                                    Download our step-by-step guide to easily complete your supplier registration and
                                    join our trusted network today!
                                </p>
                            </div>
                            <div class="col">
                                <a
                                    href="./assets/pdf/Supplier Registration Landing Page Design and Content.pdf"
                                    download
                                >
                                    <button type="button" class="btn btn-light">
                                        <span class="material-symbols-outlined"> download </span>Download
                                    </button>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="container p-5 box box-2">
                            <div class="col"><h3>List of Categories</h3></div>
                            <div class="col">
                                <p>
                                    We welcome businesses from a variety of industries. Download the full list of
                                    categories.
                                </p>
                            </div>
                            <div class="col">
                                <a
                                    href="./assets/pdf/Supplier Registration Landing Page Design and Content.pdf"
                                    download
                                >
                                    <button type="button" class="btn btn-light">
                                        <span class="material-symbols-outlined"> download </span>Download
                                    </button>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="container p-5 box box-2">
                            <div class="col"><h3>Terms and Conditions</h3></div>
                            <div class="col">
                                <p>
                                    Click the link below to view our terms and conditions for supplier registration,
                                    outlining the rules, responsibilities, and requirements.
                                </p>
                            </div>
                            <div class="col">
                                <a
                                    href="./assets/pdf/Supplier Registration Landing Page Design and Content.pdf"
                                    download
                                >
                                    <button type="button" class="btn btn-light">
                                        <span class="material-symbols-outlined"> download </span>Download
                                    </button>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="container p-5 box box-2">
                            <div class="col"><h3>Privacy Policy</h3></div>
                            <div class="col">
                                <p>
                                    Your privacy is important to us. Download our Privacy Policy to learn how we handle
                                    and protect your information.
                                </p>
                            </div>
                            <div class="col">
                                <a
                                    href="./assets/pdf/Supplier Registration Landing Page Design and Content.pdf"
                                    download
                                >
                                    <button type="button" class="btn btn-light">
                                        <span class="material-symbols-outlined"> download </span>Download
                                    </button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="section-2">
            <div class="container">
                <div class="row pt-8 mb-4">
                    <h2 class="fw-semibold headings">Frequently asked questions</h2>
                </div>

                <div class="row g-5">
                    <div class="col-8">
                        <div class="container" style="padding-left: 0 !important">
                            <div class="col-12 mb-3">
                                <div class="container mb-4 p-4 faq-box">
                                    <input id="q1" type="checkbox" class="panel" />
                                    <div class="col panel-title">
                                        <h3>
                                            <label for="q1"
                                                >Who can register as a supplier with Sri Lanka
                                                Cricket?&nbsp;&nbsp;+</label
                                            >
                                        </h3>
                                    </div>
                                    <div class="col panel-content">
                                        <p>
                                            Any business or individual providing relevant goods or services and meeting
                                            our standards of quality, integrity, and professionalism is welcome to
                                            register.
                                        </p>
                                    </div>
                                </div>
                                <div class="container mb-4 p-4 faq-box">
                                    <input id="q2" type="checkbox" class="panel" />
                                    <div class="col panel-title">
                                        <h3>
                                            <label for="q2"
                                                >Do existing suppliers need to register again?&nbsp;&nbsp;+</label
                                            >
                                        </h3>
                                    </div>
                                    <div class="col panel-content">
                                        <p>
                                            Yes, existing suppliers must renew their registration annually to ensure
                                            their information remains accurate and up to date.
                                        </p>
                                    </div>
                                </div>
                                <div class="container mb-4 p-4 faq-box">
                                    <input id="q3" type="checkbox" class="panel" />
                                    <div class="col panel-title">
                                        <h3>
                                            <label for="q3">Is there a registration fee?&nbsp;&nbsp;+</label>
                                        </h3>
                                    </div>
                                    <div class="col panel-content">
                                        <p>No, supplier registration with SLC is completely free of charge.</p>
                                    </div>
                                </div>
                                <div class="container mb-4 p-4 faq-box">
                                    <input id="q4" type="checkbox" class="panel" />
                                    <div class="col panel-title">
                                        <h3>
                                            <label for="q4"
                                                >What documents are required for supplier
                                                registration?&nbsp;&nbsp;+</label
                                            >
                                        </h3>
                                    </div>
                                    <div class="col panel-content">
                                        <ul>
                                            <li>Company registration certificate</li>
                                            <li>Tax identification details</li>
                                            <li>Proof of your products or services</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="container mb-4 p-4 faq-box">
                                    <input id="q5" type="checkbox" class="panel" />
                                    <div class="col panel-title">
                                        <h3>
                                            <label for="q5"
                                                >Can I register under multiple services or product
                                                categories?&nbsp;&nbsp;+</label
                                            >
                                        </h3>
                                    </div>
                                    <div class="col panel-content">
                                        <p>Yes, you are allowed to register under more than one category.</p>
                                    </div>
                                </div>
                                <div class="container mb-4 p-4 faq-box">
                                    <input id="q6" type="checkbox" class="panel" />
                                    <div class="col panel-title">
                                        <h3>
                                            <label for="q6"
                                                >Do I need to upload all required documents at once?&nbsp;&nbsp;+</label
                                            >
                                        </h3>
                                    </div>
                                    <div class="col panel-content">
                                        <p>
                                            Yes, all required documents must be uploaded together to complete your
                                            registration.
                                        </p>
                                    </div>
                                </div>
                                <div class="container mb-4 p-4 faq-box">
                                    <input id="q7" type="checkbox" class="panel" />
                                    <div class="col panel-title">
                                        <h3>
                                            <label for="q7"
                                                >Do I need to renew my supplier registration every
                                                year?&nbsp;&nbsp;+</label
                                            >
                                        </h3>
                                    </div>
                                    <div class="col panel-content">
                                        <p>
                                            Yes, annual renewal is mandatory to maintain an active and updated supplier
                                            status.
                                        </p>
                                    </div>
                                </div>
                                <div class="container mb-4 p-4 faq-box">
                                    <input id="q8" type="checkbox" class="panel" />
                                    <div class="col panel-title">
                                        <h3>
                                            <label for="q8">Can international suppliers register?&nbsp;&nbsp;+</label>
                                        </h3>
                                    </div>
                                    <div class="col panel-content">
                                        <p>
                                            Yes, international suppliers are welcome to register, provided they meet
                                            SLC’s requirements and submit the necessary documentation.
                                        </p>
                                    </div>
                                </div>
                                <div class="container mb-4 p-4 faq-box">
                                    <input id="q9" type="checkbox" class="panel" />
                                    <div class="col panel-title">
                                        <h3>
                                            <label for="q9"
                                                >What should I do if my application is rejected?&nbsp;&nbsp;+</label
                                            >
                                        </h3>
                                    </div>
                                    <div class="col panel-content">
                                        <p>
                                            If your application is rejected, you will receive feedback on the reasons.
                                            Address the specified issues and resubmit your application
                                        </p>
                                    </div>
                                </div>
                                <div class="container mb-4 p-4 faq-box">
                                    <input id="q10" type="checkbox" class="panel" />
                                    <div class="col panel-title">
                                        <h3>
                                            <label for="q10"
                                                >What should a supplier do if a customer asks for a
                                                blacklist?&nbsp;&nbsp;+</label
                                            >
                                        </h3>
                                    </div>
                                    <div class="col panel-content">
                                        <p>
                                            If a customer asks about a blacklist, the supplier should inform the SLC and
                                            explain the reason for the blacklisting, such as unpaid bills or contract
                                            issues. The supplier should also work on resolving the issue to remove the
                                            customer from the blacklist, following the proper procedures.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-4" style="padding-left: 0 !important">
                        <div class="col-12 d-flex mb-3">
                            <div class="container flex-grow-1 p-4 faq-box faq-box-2">
                                <div class="d-flex justify-content-center">
                                    <img class="chat-icon" src="./assets/icons/chat.png" alt="" draggable="false" />
                                </div>
                                <div class="col text-center">
                                    <h3>Do you have more questions?</h3>
                                </div>
                                <div class="col">
                                    <p class="text-center">
                                        Our system makes registration simple and efficient. Explore resources to get
                                        started, or contact us with any questions.
                                    </p>
                                </div>
                                <div class="col d-flex justify-content-center">
                                    <a href="mailto:example@example.com"
                                        ><button type="button" class="btn btn-primary faq-btn">
                                            Shoot a Direct Mail
                                        </button></a
                                    >
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
            crossorigin="anonymous"
        ></script>
    </body>
</html>
